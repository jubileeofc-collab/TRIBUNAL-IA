# TRIBUNAL IA 2.0 — Projeto Android

Aplicativo de simulação jurídica fictícia com o juiz personagem **Birula Plínio**.
O projeto contém um app Android em Kotlin/Jetpack Compose e um backend Node.js que
faz a chamada à OpenAI Responses API. A chave da API fica somente no servidor.

## Recursos implementados nesta versão
- Cadastro local de processos e áreas (cível, criminal fictício, trabalhista, consumidor, família e empresarial).
- Persistência local de processos, provas, testemunhas, histórico de audiência e sentença.
- Personagens: acusação, defesa, promotor, juiz Birula Plínio e tribunal de apelação.
- Geração de falas e sentença com contexto do processo, provas, testemunhas e histórico recente.
- Recurso/apelação narrativo.
- Configuração da URL HTTPS do backend no aplicativo.
- Compatibilidade declarada: Android 7.0 (API 24) ou superior.

## Abrir no Android Studio
1. Extraia o ZIP.
2. Abra a pasta extraída no Android Studio.
3. Aguarde a sincronização Gradle e instale os componentes Android SDK solicitados.
4. Execute em um aparelho/emulador Android 7.0+.
5. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Configurar o backend
1. Instale Node.js 20 ou superior em um servidor.
2. Entre na pasta `backend` e execute `npm install`.
3. Copie `.env.example` para `.env` e configure `OPENAI_API_KEY` e `OPENAI_MODEL`.
4. Inicie com `npm start`.
5. Publique atrás de HTTPS e configure no app a URL base, por exemplo `https://api.seudominio.com`.

Não coloque a chave da OpenAI no aplicativo Android. Use HTTPS, controle de acesso,
limites de uso e monitoramento de custos antes de disponibilizar publicamente.

## Limitações conhecidas / próxima etapa
- Esta entrega é uma versão funcional de MVP em código-fonte, não um APK compilado.
- Ainda não inclui login/contas, sincronização em nuvem, pagamentos, multiplayer, upload real de arquivos,
  reconhecimento de imagens, animações/áudio cinematográficos ou campanha com progressão.
- Os dados locais ficam no dispositivo; desinstalar o app pode apagá-los.
- A chamada de IA requer backend publicado, chave válida e acesso habilitado ao modelo escolhido.
- A simulação não substitui orientação jurídica nem representa um tribunal real.

## Build
Requer Android Studio recente, JDK 17 e Android SDK Platform 35.

## Compilar sem computador (GitHub Actions)
O ZIP inclui `.github/workflows/android-apk.yml`. Pelo celular:
1. Crie uma conta em https://github.com.
2. Crie um repositório novo e envie o conteúdo deste ZIP (os arquivos e pastas, não o ZIP fechado).
3. Abra a aba **Actions** do repositório e aguarde o fluxo **Build TRIBUNAL IA APK**.
4. Se terminar com sucesso, abra a execução e baixe o artefato `tribunal-ia-debug-apk`.
5. Extraia o artefato ZIP para encontrar o APK.

A compilação na nuvem pode revelar erros de código/dependências que ainda precisem de correção. O APK só estará disponível se a execução terminar com sucesso.

### Envio simplificado pelo celular
O fluxo GitHub Actions desta entrega está preparado para receber o arquivo
`TRIBUNAL_IA_2_0_PROJETO_COMPLETO.zip` na raiz do repositório. Depois de enviar esse ZIP,
adicione o arquivo de workflow `.github/workflows/android-apk.yml` ao repositório
(usando Add file > Create new file) com o conteúdo que acompanha este projeto.
