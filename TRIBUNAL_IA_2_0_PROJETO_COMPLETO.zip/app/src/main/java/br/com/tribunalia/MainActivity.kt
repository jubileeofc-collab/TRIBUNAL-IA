package br.com.tribunalia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Navy = Color(0xFF101B2D)
private val Navy2 = Color(0xFF1B2B43)
private val Gold = Color(0xFFC7A45B)
private val Paper = Color(0xFFF4F1E9)
private val Ink = Color(0xFF202938)

data class Evidence(val title: String, val detail: String)
data class Witness(val name: String, val statement: String)
data class Turn(val speaker: String, val text: String)
data class CaseFile(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: String,
    val summary: String,
    val evidence: List<Evidence> = emptyList(),
    val witnesses: List<Witness> = emptyList(),
    val turns: List<Turn> = emptyList(),
    val status: String = "Aguardando audiência",
    val verdict: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TribunalApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TribunalApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("tribunal_ia", 0) }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "https://SEU-SERVIDOR.com").orEmpty()) }
    var cases by remember { mutableStateOf(loadCases(prefs)) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf("Início") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var draft by remember { mutableStateOf("") }
    var speaker by remember { mutableStateOf("Advogado de defesa") }
    var newTitle by remember { mutableStateOf("") }
    var newSummary by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Cível") }
    var evidenceTitle by remember { mutableStateOf("") }
    var evidenceDetail by remember { mutableStateOf("") }
    var witnessName by remember { mutableStateOf("") }
    var witnessText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val selected = cases.firstOrNull { it.id == selectedId }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold, background = Paper)) {
        Column(Modifier.fillMaxSize().background(Paper)) {
            Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 18.dp, vertical = 16.dp)) {
                Text("TRIBUNAL IA", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("JUSTIÇA • ESTRATÉGIA • INTELIGÊNCIA ARTIFICIAL", color = Color.White.copy(alpha=.8f), fontSize=10.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Início", "Processos", "Config.").forEach { item ->
                        FilterChip(selected = tab == item, onClick = { tab = item; selectedId = null },
                            label = { Text(item) }, colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Gold, selectedLabelColor = Navy,
                                labelColor = Color.White))
                    }
                }
            }
            when {
                tab == "Config." -> {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Conexão com a inteligência artificial", fontWeight = FontWeight.Bold, fontSize = 19.sp, color=Ink)
                        Text("Informe a URL HTTPS do seu backend. A chave da OpenAI fica no servidor, nunca dentro do APK.", color=Ink)
                        OutlinedTextField(backendUrl, { backendUrl=it; prefs.edit().putString("backend_url",it).apply() },
                            label={Text("URL do backend")}, modifier=Modifier.fillMaxWidth(), singleLine=true)
                        Text("Exemplo: https://tribunal-api.seudominio.com", color=Color.Gray, fontSize=12.sp)
                        Text("Versão 2.0 • Android 7.0 ou superior", color=Color.Gray)
                    }
                }
                selected != null -> {
                    CaseScreen(
                        caseFile=selected, busy=busy, error=error, draft=draft, onDraft={draft=it},
                        speaker=speaker, onSpeaker={speaker=it},
                        evidenceTitle=evidenceTitle, onEvidenceTitle={evidenceTitle=it},
                        evidenceDetail=evidenceDetail, onEvidenceDetail={evidenceDetail=it},
                        witnessName=witnessName, onWitnessName={witnessName=it},
                        witnessText=witnessText, onWitnessText={witnessText=it},
                        onBack={selectedId=null},
                        onAddEvidence={
                            if(evidenceTitle.isNotBlank()) {
                                cases=cases.map { if(it.id==selected.id) it.copy(evidence=it.evidence+Evidence(evidenceTitle,evidenceDetail)) else it }
                                saveCases(prefs,cases); evidenceTitle=""; evidenceDetail=""
                            }
                        },
                        onAddWitness={
                            if(witnessName.isNotBlank()) {
                                cases=cases.map { if(it.id==selected.id) it.copy(witnesses=it.witnesses+Witness(witnessName,witnessText)) else it }
                                saveCases(prefs,cases); witnessName=""; witnessText=""
                            }
                        },
                        onSend={
                            val prompt=draft.trim()
                            if(prompt.isNotEmpty() && !busy) {
                                busy=true; error=""; draft=""
                                scope.launch {
                                    try {
                                        val answer=withContext(Dispatchers.IO) {
                                            callBackend(backendUrl, selected, speaker, prompt)
                                        }
                                        cases=cases.map { if(it.id==selected.id) it.copy(turns=it.turns+Turn(speaker,prompt)+Turn("TRIBUNAL IA",answer),status="Audiência em andamento") else it }
                                        saveCases(prefs,cases)
                                    } catch(e:Exception) { error=e.message ?: "Falha na conexão"; draft=prompt }
                                    finally { busy=false }
                                }
                            }
                        },
                        onVerdict={
                            if(!busy) {
                                busy=true
                                scope.launch {
                                    try {
                                        val verdict=withContext(Dispatchers.IO) {
                                            callBackend(backendUrl, selected, "Juiz Birula Plínio",
                                                "Analise o processo completo e profira uma sentença fundamentada, imparcial e clara. Diferencie fatos comprovados, alegações e dúvidas. É um jogo fictício.")
                                        }
                                        cases=cases.map { if(it.id==selected.id) it.copy(verdict=verdict,status="Sentença proferida",turns=it.turns+Turn("Juiz Birula Plínio",verdict)) else it }
                                        saveCases(prefs,cases)
                                    } catch(e:Exception) { error=e.message ?: "Falha ao gerar sentença" }
                                    finally { busy=false }
                                }
                            }
                        },
                        onAppeal={
                            val appeal="RECURSO DE APELAÇÃO: reavalie a sentença, identifique fundamentos para reforma ou manutenção e apresente argumentos das duas partes."
                            if(!busy) {
                                busy=true
                                scope.launch {
                                    try {
                                        val answer=withContext(Dispatchers.IO){callBackend(backendUrl,selected,"Tribunal de apelação",appeal)}
                                        cases=cases.map { if(it.id==selected.id) it.copy(turns=it.turns+Turn("Apelação",answer),status="Recurso analisado") else it }
                                        saveCases(prefs,cases)
                                    } catch(e:Exception){error=e.message ?: "Falha no recurso"}
                                    finally{busy=false}
                                }
                            }
                        }
                    )
                }
                tab == "Processos" -> {
                    Column(Modifier.padding(16.dp)) {
                        Text("PAINEL DE PROCESSOS", fontSize=20.sp, fontWeight=FontWeight.Bold, color=Ink)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick={tab="Início"}, colors=ButtonDefaults.buttonColors(containerColor=Navy)) { Icon(Icons.Default.Add, null); Text("  Novo processo") }
                        Spacer(Modifier.height(10.dp))
                        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            items(cases) { c ->
                                Card(Modifier.fillMaxWidth().clickable { selectedId=c.id }, colors=CardDefaults.cardColors(containerColor=Color.White)) {
                                    Column(Modifier.padding(14.dp)) {
                                        Text(c.title, fontWeight=FontWeight.Bold, color=Ink)
                                        Text("${c.category} • ${c.status}", color=Color.Gray, fontSize=12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        Text("SALA DE AUDIÊNCIAS", fontSize=20.sp, fontWeight=FontWeight.Bold, color=Ink)
                        Text("Crie um caso, reúna provas, ouça testemunhas e conduza uma audiência com personagens controlados por IA.", color=Ink)
                        OutlinedTextField(newTitle,{newTitle=it},label={Text("Título do processo")},modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(newSummary,{newSummary=it},label={Text("Resumo dos fatos")},modifier=Modifier.fillMaxWidth(),minLines=3)
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
                            OutlinedTextField(newCategory,{},readOnly=true,label={Text("Área")},modifier=Modifier.menuAnchor().fillMaxWidth(),trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
                            ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                                listOf("Cível","Criminal fictício","Trabalhista","Consumidor","Família","Empresarial").forEach { item ->
                                    DropdownMenuItem(text={Text(item)},onClick={newCategory=item;expanded=false})
                                }
                            }
                        }
                        Button(onClick={
                            if(newTitle.isNotBlank() && newSummary.isNotBlank()) {
                                val c=CaseFile(title=newTitle,category=newCategory,summary=newSummary)
                                cases= listOf(c)+cases; saveCases(prefs,cases); selectedId=c.id; tab="Processos"; newTitle="";newSummary=""
                            }
                        }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Navy)) {
                            Icon(Icons.Default.Gavel,null); Text("  Abrir novo processo")
                        }
                        Text("Destaque: Juiz Birula Plínio", color=Gold, fontWeight=FontWeight.Bold)
                        Text("Personagem fictício • entretenimento e simulação", color=Color.Gray, fontSize=12.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CaseScreen(
    caseFile: CaseFile, busy:Boolean, error:String, draft:String, onDraft:(String)->Unit,
    speaker:String,onSpeaker:(String)->Unit,evidenceTitle:String,onEvidenceTitle:(String)->Unit,
    evidenceDetail:String,onEvidenceDetail:(String)->Unit,witnessName:String,onWitnessName:(String)->Unit,
    witnessText:String,onWitnessText:(String)->Unit,onBack:()->Unit,onAddEvidence:()->Unit,
    onAddWitness:()->Unit,onSend:()->Unit,onVerdict:()->Unit,onAppeal:()->Unit
) {
    var section by remember { mutableStateOf("Audiência") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}
            Column(Modifier.weight(1f)) {
                Text(caseFile.title,fontWeight=FontWeight.Bold,color=Ink)
                Text("${caseFile.category} • ${caseFile.status}",fontSize=11.sp,color=Color.Gray)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=10.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("Audiência","Provas","Testemunhas","Sentença").forEach {
                FilterChip(selected=section==it,onClick={section=it},label={Text(it,fontSize=11.sp)})
            }
        }
        when(section) {
            "Provas" -> LazyColumn(Modifier.weight(1f).padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                item {
                    Text("JUNTADA DE PROVAS",fontWeight=FontWeight.Bold)
                    OutlinedTextField(evidenceTitle,onEvidenceTitle,label={Text("Nome da prova")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(evidenceDetail,onEvidenceDetail,label={Text("Descrição / conteúdo")},modifier=Modifier.fillMaxWidth(),minLines=2)
                    Button(onClick=onAddEvidence){Text("Adicionar prova")}
                    Text("Provas registradas",fontWeight=FontWeight.Bold)
                }
                items(caseFile.evidence){e->Card { Column(Modifier.padding(12.dp)){Text(e.title,fontWeight=FontWeight.Bold);Text(e.detail)} }}
            }
            "Testemunhas" -> LazyColumn(Modifier.weight(1f).padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                item {
                    Text("ROL DE TESTEMUNHAS",fontWeight=FontWeight.Bold)
                    OutlinedTextField(witnessName,onWitnessName,label={Text("Nome da testemunha")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(witnessText,onWitnessText,label={Text("Depoimento")},modifier=Modifier.fillMaxWidth(),minLines=2)
                    Button(onClick=onAddWitness){Text("Registrar depoimento")}
                }
                items(caseFile.witnesses){w->Card { Column(Modifier.padding(12.dp)){Text(w.name,fontWeight=FontWeight.Bold);Text(w.statement)} }}
            }
            "Sentença" -> Column(Modifier.weight(1f).padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                Button(onClick=onVerdict,enabled=!busy,modifier=Modifier.fillMaxWidth()){Text("Juiz Birula Plínio: proferir sentença")}
                Button(onClick=onAppeal,enabled=!busy,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Navy)){Text("Interpor recurso / apelação")}
                if(caseFile.verdict.isNotBlank()) Text(caseFile.verdict,color=Ink)
            }
            else -> Column(Modifier.weight(1f).padding(horizontal=14.dp)) {
                Text("FATOS DO PROCESSO",fontWeight=FontWeight.Bold,color=Ink)
                Text(caseFile.summary,color=Ink)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    items(caseFile.turns){t->
                        Card(colors=CardDefaults.cardColors(containerColor=if(t.speaker=="TRIBUNAL IA") Navy2 else Color.White)) {
                            Column(Modifier.padding(10.dp)) {
                                Text(t.speaker,fontWeight=FontWeight.Bold,color=if(t.speaker=="TRIBUNAL IA") Gold else Ink)
                                Text(t.text,color=if(t.speaker=="TRIBUNAL IA") Color.White else Ink)
                            }
                        }
                    }
                }
                if(error.isNotBlank()) Text(error,color=Color.Red,fontSize=12.sp)
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
                    OutlinedTextField(speaker,{},readOnly=true,label={Text("Personagem")},modifier=Modifier.menuAnchor().fillMaxWidth(),trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
                    ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                        listOf("Advogado de acusação","Advogado de defesa","Promotor","Juiz Birula Plínio").forEach {
                            DropdownMenuItem(text={Text(it)},onClick={onSpeaker(it);expanded=false})
                        }
                    }
                }
                OutlinedTextField(draft,onDraft,label={Text("Fale na audiência...")},modifier=Modifier.fillMaxWidth(),minLines=2)
                Button(onClick=onSend,enabled=!busy,modifier=Modifier.fillMaxWidth()) {
                    if(busy) CircularProgressIndicator(modifier=Modifier.size(18.dp),strokeWidth=2.dp) else Icon(Icons.Default.Send,null)
                    Text("  Enviar fala")
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

private fun callBackend(url:String, c:CaseFile, role:String, prompt:String):String {
    require(url.startsWith("https://")) { "Configure uma URL HTTPS válida na aba Config." }
    val evidence=c.evidence.joinToString("\n"){"- ${it.title}: ${it.detail}"}
    val witnesses=c.witnesses.joinToString("\n"){"- ${it.name}: ${it.statement}"}
    val history=c.turns.takeLast(12).joinToString("\n"){"${it.speaker}: ${it.text}"}
    val payload=JSONObject().put("case",JSONObject()
        .put("title",c.title).put("category",c.category).put("summary",c.summary)
        .put("evidence",evidence).put("witnesses",witnesses).put("history",history))
        .put("role",role).put("prompt",prompt)
    val body=payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
    val req=Request.Builder().url(url.trimEnd('/')+"/api/hearing").post(body).build()
    OkHttpClient().newCall(req).execute().use { response ->
        val text=response.body?.string().orEmpty()
        if(!response.isSuccessful) throw IllegalStateException("Servidor respondeu ${response.code}: $text")
        JSONObject(text).optString("answer").ifBlank { "A IA não retornou conteúdo." }
    }
}

private fun saveCases(prefs:android.content.SharedPreferences,cases:List<CaseFile>) {
    val arr=JSONArray()
    cases.forEach { c ->
        fun strings(list:List<String>)=JSONArray().also { a->list.forEach(a::put) }
        val ev=JSONArray(); c.evidence.forEach{ev.put(JSONObject().put("title",it.title).put("detail",it.detail))}
        val wi=JSONArray(); c.witnesses.forEach{wi.put(JSONObject().put("name",it.name).put("statement",it.statement))}
        val tu=JSONArray(); c.turns.forEach{tu.put(JSONObject().put("speaker",it.speaker).put("text",it.text))}
        arr.put(JSONObject().put("id",c.id).put("title",c.title).put("category",c.category).put("summary",c.summary)
            .put("evidence",ev).put("witnesses",wi).put("turns",tu).put("status",c.status).put("verdict",c.verdict))
    }
    prefs.edit().putString("cases",arr.toString()).apply()
}
private fun loadCases(prefs:android.content.SharedPreferences):List<CaseFile> {
    return try {
        val arr=JSONArray(prefs.getString("cases","[]"))
        (0 until arr.length()).map { i ->
            val o=arr.getJSONObject(i)
            fun readObjects(key:String, a:String,b:String)= (0 until o.optJSONArray(key).length()).map { j ->
                val x=o.getJSONArray(key).getJSONObject(j); x.optString(a) to x.optString(b)
            }
            val ev=readObjects("evidence","title","detail").map{Evidence(it.first,it.second)}
            val wi=readObjects("witnesses","name","statement").map{Witness(it.first,it.second)}
            val tu=readObjects("turns","speaker","text").map{Turn(it.first,it.second)}
            CaseFile(o.getString("id"),o.getString("title"),o.getString("category"),o.getString("summary"),
                ev,wi,tu,o.optString("status"),o.optString("verdict"))
        }
    } catch(_:Exception){ emptyList() }
}
