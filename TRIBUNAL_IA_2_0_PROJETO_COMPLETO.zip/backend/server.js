import express from "express";

const app = express();
app.use(express.json({ limit: "1mb" }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "TRIBUNAL IA" }));

app.post("/api/hearing", async (req, res) => {
  try {
    const { case: c, role, prompt } = req.body ?? {};
    if (!c?.title || !c?.summary || !role || !prompt) {
      return res.status(400).json({ error: "Dados obrigatórios ausentes." });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "OPENAI_API_KEY não configurada no servidor." });
    }

    const instructions = `
Você é o motor narrativo do TRIBUNAL IA, um jogo de simulação jurídica fictícia em português brasileiro.
O juiz personagem é Birula Plínio: personalidade marcante, formal, firme e ocasionalmente irônica, sem perder clareza.
Interprete o papel indicado pelo jogador: ${role}.
É entretenimento, não aconselhamento jurídico. Não afirme que decisões fictícias têm validade real.
Considere fatos, provas, testemunhas e histórico abaixo. Separe alegações de fatos comprovados.
Não invente prova ou depoimento. Se faltarem dados, faça perguntas ou reconheça incerteza.
Caso: ${c.title}
Área: ${c.category}
Resumo: ${c.summary}
Provas juntadas:
${c.evidence || "Nenhuma prova cadastrada."}
Testemunhas:
${c.witnesses || "Nenhuma testemunha cadastrada."}
Histórico recente:
${c.history || "Audiência ainda não iniciada."}
Responda de modo imersivo, profissional, realista e adequado ao papel.`;

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6-astra",
        instructions,
        input: prompt,
        max_output_tokens: 1200
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data?.error?.message || "Erro na API de IA." });
    }
    const answer = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text)
      .join("\n")
      .trim();

    return res.json({ answer: answer || "A IA não retornou texto." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Erro interno no servidor." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`TRIBUNAL IA backend ativo na porta ${port}`));
